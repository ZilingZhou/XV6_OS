code change in following place:
1. kalloc.c
2. vm.c
3. trap.c 	//just a handler passing err # to pagefault in vm.c
4. mmu.h    //COW flag added
5. defs.h   //linking the function calls
6. unit test in forkUnittest

1. In kalloc.c we add the reference count to to page descriptor structure, in struct run.
When kernel just boot up, it goes through kfree2(char* v) similar to the original kfree(char* v). 
In the new kfree(char* v), we assert the reference count is 1 when we free a page, and 0 after
freeing that page. We also modify kalloc, when a page is alloc the reference count for it is 1.
3 additional helper function for getting reference count, increasing,and decreasing it also added.

2. We modify deallocuvm, we only free the page when only one process(count = 1) is using it, else
we just reduce the count on the page.
We implement cowuvm, this is similar the original copyuvm but we don't alloc memory for the child
process. Instead, we check if parent process is writable, if yes we make it readonly and cow. If 
parent is readonly, keep it readonly. Finally, increase reference count and flush tlb(protection
bit changed).
We implement pagefault, we first check if the faulting address is within the user address space,
if not kill the process. Then we get the pte from the faulting address(with cast). Check if pte
is valid(page present?). 
We will then check the err #. If we have a read violation, end process.
							  If we have a write violation, but not cow, end process(This is 
							  usually caused by a readonly parent fork a child, but child tries
							  to write to memory that should also be readonly(inherit readonly))
We now encounter a write fault under case pte with readonly and cow flag.
check the count on page:	if > 1 many process is sharing the readonly file, the one tries to
									write to memory needs to alloc its new page
							else if = 1 only one process remaining it now regain the power to write
							else we got unexpected problem(should not happen). 

6. a unit test consist of 4 test is include
   1st test for excercise two invlaid address access(user access kernel space)
   2nd test for checking parent memory different than child when child write something
   3rd test for multiple forking, then wait for child, when only parent is left, parent should 
   		regain the ability to write.
   4th test for forking a child of a parent having readonly data. try to modify the data.
