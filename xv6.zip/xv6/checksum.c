#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"

int buffsize = 128;
typedef struct {
	//extra char for full case
	volatile char buff[128];
	volatile int head;
	//tail is next free
	volatile int tail;
	volatile int total;
	volatile int done;
	volatile mutex_t m;
	volatile cond_var_t c;
	volatile cond_var_t p;
} shm_t;


int main (int argc, char* argv[]){
	int fd = open("README", O_RDONLY);
	char buff[4096];
	int readed;
	int echecksum = 0;
	while ((readed = read(fd, buff, 4096)) != 0) {
		for (int i = 0; i < readed; i++) {
			echecksum = echecksum + (int)buff[i];
		}
	}
	printf(1, "Expected checksum %d\n",echecksum);
	close(fd);

	shm_t* mem = (shm_t*) shmbrk(sizeof(shm_t));
	memset(mem, 0, sizeof(shm_t));
	cv_init((cond_var_t*) &(mem->c));
	cv_init((cond_var_t*) &(mem->p));
	mutex_init((mutex_t*) &(mem->m));
	
	fd = open("README", O_RDONLY);
	int pid;

	for(int i = 0; i <4;i++)
		pid = fork();
	//c
	if(pid){
		
	}
	//p
	else{

	}
}