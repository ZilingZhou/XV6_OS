#include "types.h"
#include "stat.h"
#include "user.h"
//#include "defs.h"
void cowforktest1() {
	printf(2, "cowtest%d begin\n", 1);
	char* alp = "abc";
	if(!fork()){
		alp = "a";
		exit();
	}
	printf(2, "%s\n",alp);
	wait();
		printf(2, "cowtest1 success with two different outputs\n");
}

void cowforktest2() {
	printf(2, "cowtest%d begin\n", 2);
	char* alp = "abc";
	if(!fork()){
                alp = "abc";
		printf(2, "print:%s, child ends\n", alp);
		exit();
	}else{
		wait();
		alp = "cba";
		printf(2, "print:%s, cowtest2 success\n", alp);
	}

}

/*
* Fork and have a child that page faults
*/

void cowforktest3() {
	printf(2, "cowtest%d begin\n", 3);
	char* alp = "abcde";
	if(!fork()){
		if(!fork()){
			alp = "a";
			printf(2, "child ofchild change print:%s\n", alp);
			exit();
		}
		else{
			wait();
			alp = "b";
			printf(2, "child change print:%s\n", alp);
		}
		exit();
	}else{
		wait();
		printf(2, "print: %s not changed \n all test complete and succeed\n", alp);
	}
}

void excercise2test(){
	printf(2, "excercise2test begin\n");
	if(!fork()){
		printf(2, "PAGE FAULTING ON PURPOSE FOR READING KERNEL\n");
		int* p = (int*)(0x80000000 + 0xfff);
		printf(2, "*d\n",*p);
		exit();
	}else{
		wait();
		printf(2, "excercise2test success\n");
	}
}
int main(void) {
  excercise2test();
  cowforktest1();
  cowforktest2();
  cowforktest3();
  exit();
}
