#include "types.h"
#include "user.h"


void checkInvalidAddress(void* addr){
	
	printf(2, "Check the character here: %c\n", *(char*)addr);
}


int main(int argc,char** argv){
        void *i = (void*)0x00002000;
        checkInvalidAddress(i);
        exit();
}

