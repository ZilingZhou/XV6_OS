#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc,char** argv){
        char* ptr = (void*)0;
 	char a = *ptr;
	printf(2,"%s",a);
	exit();
}

