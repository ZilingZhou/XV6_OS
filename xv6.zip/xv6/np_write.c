#include "types.h"
#include "stat.h"
#include "user.h"
//#include <stdio.h>

int main(int argc,char** argv){
        char* str = (void*)0;
	char* toMove = "abc";
	memmove(str,toMove,3);
        printf(2,"%s",str);
//	printf("%s", str);        
        exit();
}


