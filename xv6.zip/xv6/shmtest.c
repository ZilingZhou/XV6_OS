#include "types.h"
#include "user.h"
#include "syscall.h"

int main (int argc, char* argv[]){
	printf(1, "Program starts here\n");
	char * string = (char*)shmbrk(4096);
	memset(string, 0, 10);
	if(!fork()){
		memmove(string+3, "306", 3);
		if(!fork()){
			memmove(string+6, "hhh", 3);
			exit();
		}
		wait();
		exit();
	}
	wait();
	memmove(string,"cse", 3);
	printf(1, "The result is: %s\n", string);
	exit();
}