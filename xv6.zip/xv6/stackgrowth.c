#include "types.h"
#include "stat.h"
#include "user.h"
//#include <stdio.h>
void stackflow(int call){
//	if(call != 0){
         // char 4byte = "abcd";
	 if(call % 100 == 0 )
	   printf(2,"%d\n",call);
	   int i = 0;
	   if(call < 1000)
             stackflow(++call);
	   i++;
	   printf(2,"%s","");
//	   fflush();
//	   printf(2,"ignore this println: %d\n",i);
//	}
//	int i = 0;//wast stack mem
//	i++;
}
void stackoverflow(){
	int i = 0;
	printf(2,"%s","");
	stackoverflow();
	i++;
	printf(2,"%s","");
}
int main(int argc,char** argv){
      	int i = 0;
    	stackflow(i);
	printf(2,"%s","ready to get overflow by recursive call, expecting pagefault!\n");
	if(!fork()){	
	stackoverflow();
	exit();      	
 	}
	 wait();
	exit();	
}



