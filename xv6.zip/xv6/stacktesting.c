#include "types.h"
#include "stat.h"
#include "user.h"


int main(int argc,char** argv){
      //  char* str = (char*)malloc(250);
      //  wolfie(str,250);
      //  printf(2,"%s", str);
       	static int arg[10000];
	for(int i = 0; i < 10000 ;i++)
	  arg[i] = i;

	for(int i = 0; i < 10000 ;i++)
        printf(2,"%d\n",arg[i]);	

	 exit();

}

