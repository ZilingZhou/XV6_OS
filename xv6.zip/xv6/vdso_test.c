#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc,char** argv){
        unsigned int thispid = getpid();
	unsigned int thatpid = vdso_getpid();
        printf(2,"this pid %d should equal that pid %d\n", thispid,thatpid);
       	if(thispid != thatpid)
		printf(2,"%s","failed test");
	int loop = 0;
	while(loop < 10){
	  printf(2,"current tick %d\n",vdso_getticks());
	  loop++;
	}
	 exit();

}

