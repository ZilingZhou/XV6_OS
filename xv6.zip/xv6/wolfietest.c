#include "types.h"
#include "stat.h"
#include "user.h"


int main(int argc,char** argv){
	char* str = (char*)malloc(250);
	wolfie(str,250);
	printf(2,"%s", str);
	exit();

}
